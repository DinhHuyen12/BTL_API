﻿namespace baiapi1.DTO
{
    public class LoanDTO
    {
    
        public string Title { get; set; }    
        public string Image { get; set; }
        public DateTime BorrowDate { get; set; } 
        public DateTime DueDate { get; set; }
    }
}
